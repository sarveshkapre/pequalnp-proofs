# Three ordinary rows in the 28-gate grid

[Proof and offline replay instructions](work/plane-matching/row-cut/THREE_ROWS.md).
