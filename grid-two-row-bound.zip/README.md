# Four ordinary rows in the grid

[Read the proof and offline replay instructions](work/plane-matching/row-cut/TWO_ROWS.md). The evidence directory contains twelve LRAT certificates and the decoded positive controls.
